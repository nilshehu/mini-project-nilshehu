# 🗳️ Votim Live

### Dokumentacion Teknik dhe Arkitektura e Aplikacionit të Sondazheve në Kohë Reale

| Fusha | Përshkrimi |
|---|---|
| **TEKNOLOGJIA FRONTEND** | Flutter / Dart (DartPad Compatible) |
| **BACKEND & DATABAZA** | Supabase (Auth & PostgREST Database) |
| **TIPI I DOKUMENTIT** | Specifikim Teknik & Udhëzues Përdorimi |
| **DATA E PUBLIKIMIT** | Tetor 2026 |

---

## 1. Plani Strategjik dhe Struktura MVP (K1, K2)

Aplikacioni **Votim Live** adreson nevojën për një platformë të thjeshtë, të sigurt dhe me përditësime në kohë reale për kryerjen e sondazheve dhe votimeve interaktive në komunitete akademike ose profesionale.

| Faza | Kërkesa | Zgjidhja Teknike |
|---|---|---|
| **1. Problemi** | Nevoja për votim transparent | Platformë dixhitale për votime të menjëhershme me rezultate në kohë reale. |
| **2. Përdoruesit** | Grupet e synuara | Nxënësit, studentët, mësimdhënësit dhe menaxhmenti për vendimmarrje të shpejtë. |
| **3. Ekranet** | Struktura e ndërfaqes | Ekranet e Autentikimit, Listës së Sondazheve, Detajeve të Votimit dhe Profilit. |
| **4. Databaza** | Skema e të dhënave | Tabela `polls` me fushat përkatëse për ruajtjen e votave, autorësisë dhe votuesve. |
| **5. Rrjedha** | Eksperienca e përdoruesit | Kyçje $\rightarrow$ Shfletim $\rightarrow$ Krijim sondazhi $\rightarrow$ Votim live $\rightarrow$ Mbyllje ose fshirje nga autori. |

---

## 2. Skica Arkitekturale e Ekraneve

Më poshtë paraqiten skicat e ekraneve kryesore bazuar në rrjedhën nga kyçja, te shfletimi dhe votimi në kohë reale:

```text
       +---------------------------------------------+
       |           1. Ekrani i Autentikimit          |
       |       (Supabase Auth: Sign In / Sign Up)    |
       +----------------------+----------------------+
                              |
                     [ Sesioni i Vlefshëm ]
                              |
                              v
     +-------------------------------------------------+
     |        HomeShell (NavigationBar me 3 Tab-e)     |
     +-------------------+--------------------+--------+
                         |                    |
        +----------------+                    +----------------+
        |                                                      |
        v                                                      v
+-----------------------+                            +-----------------------+
|  2. Lista e Votimeve  |                            |   4. Ekrani i Profilit|
|  - ChoiceChips Filtrat|                            |  - Të dhënat e emailit|
|  - StreamBuilder Live |                            |  - Dark Mode Toggle   |
|  - Butoni [+ Krijo]   |                            |  - Butoni "Dil"       |
+-----------+-----------+                            +-----------------------+
            |
   +--------+--------+
   |                 |
   v                 v
+------------------+ +----------------------------------------------------+
| 3. Forma Modale  | | 5. Faqja e Detajeve dhe Votimit Live               |
| Krijim Sondazhi  | | - Përqindjet e votave me LinearProgressIndicator   |
| (Pyetja, Opt A/B)| | - Butonat e votimit (Mbrojtje nga votimi i dyfishtë|
+------------------+ | - Mbyllja e sondazhit (vetëm pronari)              |
                     +----------------------------------------------------+
```

---

## 3. Specifikimet e Funksionaliteteve (K3 – K18)

* **Modeli i të Dhënave (Poll Model - K3):** Strukturim i të dhënave për llogaritjen automatike të përqindjeve të votave (`percentA`, `percentB`, `totalVotes`) dhe mundësimin e filtrimit sipas statusit e pronësisë (`isMine`, `hasVoted`).
* **Menaxhimi i Gjendjeve (StreamBuilder - K5, K6):** Trajtimi i plotë i katër gjendjeve të ndërfaqes: Pritje (*Waiting*), Gabim (*Error* me mundësi ri-tentimi), Bosh (*Empty*), dhe me Të Dhëna (*Data* përmes `ListView.builder`).
* **Autentikimi i Sigurt (K7):** Integrim i plotë me Supabase Auth për kyçje, regjistrim dhe ruajtje të sesionit aktiv të përdoruesit me Bearer token.
* **Sistemi i Votimit në Kohë Reale (K8, K11):** Ndërfaqe me shirita progresi vizual (`LinearProgressIndicator`) dhe mekanizëm për parandalimin e votimit të dyfishtë nga i njëjti përdorues.
* **Krijimi dhe Validimi (K9, K10):** Formë modale për krijimin e pyetjeve të reja me validim fushash për të parandaluar dërgimin e të dhënave të zbrazëta.
* **Fshirja e Sigurt (K12):** Vetëm krijuesi mund ta fshijë sondazhin e tij me konfirmim paraprak, e garantuar edhe në bazë të RLS policies në PostgreSQL.
* **Sistemi i Sinkronizimit (K13):** Përditësim periodik i të dhënave çdo 5 sekonda përmes `Timer.periodic` dhe `StreamController`.
* **Filtrimi i Avancuar (K14):** Segmentim me `ChoiceChip` (Të gjitha / Aktive / Të mbyllura) dhe tab-i i veçantë "Votimet e Mia".
* **Dizajni dhe Tema (K15, K16, K17):** Ndërtuar me standartet **Material 3**, me mbështetje për temën e errët (**Dark Mode**) dhe lundrim përmes `NavigationBar`.
* **Feedback Vizual (K18):** Njoftime të menjëhershme me `SnackBar` për çdo veprim (krijim, votim, mbyllje, fshirje, gabime).

---

## 4. Pamje nga Ndërfaqja e Aplikacionit (Udhëzuesi i Përdorimit)

Më poshtë paraqitet galeria e plotë e ekraneve të aplikacionit funksional së bashku me instruksionet hap pas hapi:

---

### Figura 1: Ekrani i Hyrjes dhe Regjistrimit
![Figura 1: Ekrani i Hyrjes dhe Regjistrimit](figura1_login.png)
* **Funksioni:** Autentikimi i sigurt i përdoruesit.
* **Instruksione:**
  1. Shkruani adresën tuaj të email-it (`ns278@bgt.school`) dhe fjalëkalimin tuaj (të paktën 6 karaktere).
  2. Klikoni butonin **Kyçu** nëse keni tashmë një llogari, ose butonin **Regjistrohu** për krijimin e një llogarie të re.
  3. Pas suksesit, ruhet tokeni i sesionit dhe përdoruesi drejtohet automatikisht te ekrani kryesor.

---

### Figura 2: Lista e Sondazheve (Shteti Bosh)
![Figura 2: Lista e Sondazheve (Shteti Bosh)](figura2_lista_bosh.png)
* **Funksioni:** Paraqitja fillestare e listës kur ende nuk ka asnjë sondazh të regjistruar në sistem.
* **Instruksione:**
  1. Ekrani shfaq qartë njoftimin: *"Asnjë votim i gjetur në këtë filtër."*.
  2. Në krye ndodhen filtrat me `ChoiceChip` (*Të gjitha*, *Aktive*, *Të mbyllura*).
  3. Për të shtuar sondazhin e parë, klikoni butonin lundrues **`+ Krijo Votim`** në pjesën e poshtme djathtas.

---

### Figura 3: Forma Modale për Krijimin e Sondazhit
![Figura 3: Forma Modale për Krijimin e Sondazhit](figura3_forma_krijimit.png)
* **Funksioni:** Regjistrimi i pyetjes së re dhe përcaktimi i dy alternativave të votimit.
* **Instruksione:**
  1. Shkruani temën/pyetjen te fusha **"Pyetja e sondazhit"** (p.sh. *buk*).
  2. Vendosni opsionin e parë te **"Opsioni A"** (p.sh. *burger*).
  3. Vendosni opsionin e dytë te **"Opsioni B"** (p.sh. *pite*).
  4. Shtypni **Krijo**. Forma kryen validimin e fushave dhe dërgon kërkesën `POST` në Supabase.

---

### Figura 4: Menaxhimi i Votimeve Personale
![Figura 4: Menaxhimi i Votimeve Personale](figura4_votimet_mia.png)
* **Funksioni:** Filtrimi dhe menaxhimi i sondazheve të krijuara vetëm nga përdoruesi aktual.
* **Instruksione:**
  1. Zgjidhni tab-in **"Të miat"** nga shiriti i navigimit në fund të ekranit.
  2. Këtu shfaqen vetëm votimet që mbajnë autorësinë tuaj.
  3. Njoftimi me SnackBar *"U publikua votimi: buk 🎉"* konfirmon publikimin e suksesshëm në kohë reale.

---

### Figura 5: Rezultatet në Kohë Reale
![Figura 5: Rezultatet në Kohë Reale](figura5_rezultatet_live.png)
* **Funksioni:** Ekrani i detajeve ku përdoruesit votojnë dhe shohin rezultatet live.
* **Instruksione:**
  1. Zgjidhni alternativën e dëshiruar dhe shtypni **Voto**.
  2. Shiriti me ngjyrë (`LinearProgressIndicator`) llogarit dhe shfaq menjëherë përqindjen e saktë (p.sh. *100.0% (1 vota)*).
  3. Njoftimi *"Vota juaj u regjistrua me sukses! 🎉"* konfirmon votimin, dhe sistemi parandalon votimin e dytë.
  4. Pronari i sondazhit ka gjithashtu butonin për ta mbyllur votimin në çdo kohë.

---

### Figura 6: Lista me Sondazhe të Kryera
![Figura 6: Lista me Sondazhe të Kryera](figura6_lista_votimeve.png)
* **Funksioni:** Pamja e plotë e të gjitha sondazheve në qarkullim me gjendjen e votimit.
* **Instruksione:**
  1. Lista përditësohet automatikisht çdo 5 sekonda me të dhënat më të reja nga të gjithë përdoruesit.
  2. Sondazhet ku keni votuar shënohen me simbolin e gjelbër: **"✅ Keni votuar"**.
  3. Çdo kartelë tregon autorin, datën, orën, numrin total të votave dhe statusin (Aktiv/Mbyllur).

---

### Figura 7: Filtrimi sipas Statusit Mbyllur
![Figura 7: Filtrimi sipas Statusit Mbyllur](figura7_filtri_mbyllur.png)
* **Funksioni:** Veçimi i sondazheve që kanë përfunduar dhe nuk pranojnë më vota.
* **Instruksione:**
  1. Klikoni mbi filtrin **"Të mbyllura"**.
  2. Shfaqen vetëm votimet e mbyllura me ikonën e kyçit dhe etiketën gri *"Mbyllur"*.
  3. Përdoruesit mund të klikojnë mbi to për të parë rezultatet përfundimtare, por butonat e votimit mbeten të çaktivizuar.

---

### Figura 8: Profili dhe Konfigurimi i Temës
![Figura 8: Profili dhe Konfigurimi i Temës](figura8_profili.png)
* **Funksioni:** Menaxhimi i preferencave të llogarisë dhe stilit vizual.
* **Instruksione:**
  1. Zgjidhni tab-in **"Profili"** në shiritin e navigimit.
  2. Shikohen të dhënat e identifikimit me avatarin personal dhe email-in.
  3. Butoni switch **"Dark Mode (Tema e Errët)"** mundëson ndërrimin e menjëhershëm midis temës së çelët dhe asaj të errët.
  4. Butoni **"Dil (Sign Out)"** përfundon sesionin aktual në mënyrë të sigurt.

---

## 5. Udhëzuesi i Konfigurimit dhe Ekzekutimit

### Hapi 1: Konfigurimi i Supabase
1. Qasuni në panelin e Supabase, hapni **SQL Editor** dhe ekzekutoni skriptin `Day5_SQL.txt`:
   ```sql
   drop table if exists public.polls cascade;

   create table public.polls (
     id bigint generated always as identity primary key,
     user_id uuid not null references auth.users default auth.uid(),
     author text not null,
     question text not null check (char_length(question) between 3 and 150),
     option_a text not null check (char_length(option_a) between 1 and 60),
     option_b text not null check (char_length(option_b) between 1 and 60),
     votes_a int not null default 0 check (votes_a >= 0),
     votes_b int not null default 0 check (votes_b >= 0),
     voters text[] not null default '{}'::text[],
     status text not null default 'aktiv' check (status in ('aktiv', 'mbyllur')),
     created_at timestamptz not null default now()
   );

   alter table public.polls enable row level security;
   grant select, insert, update, delete on table public.polls to authenticated;

   create policy "Lexojne te kycurit" on public.polls for select to authenticated using (true);
   create policy "Shton si vetja" on public.polls for insert to authenticated with check ((select auth.uid()) = user_id);
   create policy "Kycurit votojne dhe pronari ndryshon" on public.polls for update to authenticated using (true) with check (true);
   create policy "Pronari fshin" on public.polls for delete to authenticated using ((select auth.uid()) = user_id);
   ```
2. Te **Authentication** $\rightarrow$ **Providers** $\rightarrow$ **Email**, çaktivizoni opsionin **Confirm email** për të lejuar kyçjen e menjëhershme pa pritje.

### Hapi 2: Lidhja me DartPad / Flutter
1. Hapni mjedisin **DartPad** me mbështetje Flutter.
2. Kopjoni kodin e skedarit `main.dart`. Kredencialet tuaja janë të integruara:
   ```dart
   const supabaseUrl = 'https://csegdoxrrybugsctpvmw.supabase.co';
   const supabaseKey = 'sb_publishable_SgDqg_5fPAduPUnjWjkF_A_QZlwEovp';
   ```
3. Shtypni butonin **Run**.

---

## 6. Plani i Zhvillimit të Mëtejshëm

* **Opsione Shumëfishta:** Zgjerimi i sistemit nga 2 opsione në mundësi për numër të pakufizuar opsionesh për pyetje.
* **Diskutime Live:** Integrimi i një seksioni komentesh për çdo sondazh aktiv.
* **Eksportimi i Të Dhënave:** Mundësia e gjenerimit dhe eksportimit të raporteve në format PDF ose CSV.
