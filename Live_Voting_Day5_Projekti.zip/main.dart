// ======================================================================
// Mini-projekti: Votim Live (Live Voting App)
// Kërkesat K1 – K20 të implementuara dhe të shënuara në komentet përkatëse.
// I përshtatshëm 100% për DartPad dhe FlutLab.
// ======================================================================

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// KONSIGURIMI I SUPABASE (Zëvendësoni me kredencialet tuaja)
const supabaseUrl = 'https://csegdoxrrybugsctpvmw.supabase.co';
const supabaseKey = 'sb_publishable_SgDqg_5fPAduPUnjWjkF_A_QZlwEovp';
const authUrl = '$supabaseUrl/auth/v1';
const pollsUrl = '$supabaseUrl/rest/v1/polls';

void main() {
  runApp(const MyApp());
}

// ======================= AUTH & SESIONI (K7) =======================
class Session {
  final String accessToken;
  final String userId;
  final String email;

  const Session({
    required this.accessToken,
    required this.userId,
    required this.email,
  });

  factory Session.fromJson(Map<String, dynamic> json) {
    return Session(
      accessToken: json['access_token'],
      userId: json['user']['id'],
      email: json['user']['email'] ?? '',
    );
  }
}

Session? currentSession;

Map<String, String> authHeaders() {
  final headers = {
    'apikey': supabaseKey,
    'Content-Type': 'application/json',
  };
  final session = currentSession;
  if (session != null) {
    headers['Authorization'] = 'Bearer ${session.accessToken}';
  }
  return headers;
}

String authError(http.Response response) {
  try {
    final data = jsonDecode(response.body);
    return (data['msg'] ?? data['error_description'] ?? 'Gabim ${response.statusCode}').toString();
  } catch (_) {
    return 'Gabim ${response.statusCode}: ${response.body}';
  }
}

Future<Session> signUp(String email, String password) async {
  final response = await http.post(
    Uri.parse('$authUrl/signup'),
    headers: authHeaders(),
    body: jsonEncode({'email': email, 'password': password}),
  );
  if (response.statusCode != 200) {
    throw Exception(authError(response));
  }
  final data = jsonDecode(response.body);
  if (data['access_token'] == null) {
    throw Exception('Konfirmoni email-in ose çaktivizoni "Confirm email" në Supabase Auth Settings.');
  }
  return Session.fromJson(data);
}

Future<Session> signIn(String email, String password) async {
  final response = await http.post(
    Uri.parse('$authUrl/token?grant_type=password'),
    headers: authHeaders(),
    body: jsonEncode({'email': email, 'password': password}),
  );
  if (response.statusCode != 200) {
    throw Exception(authError(response));
  }
  return Session.fromJson(jsonDecode(response.body));
}

Future<void> signOut() async {
  try {
    await http.post(Uri.parse('$authUrl/logout'), headers: authHeaders());
  } catch (_) {}
}

// ======================= MODELI I TË DHËNAVE (K3) =======================
class Poll {
  final int id;
  final String userId;
  final String author;
  final String question;
  final String optionA;
  final String optionB;
  final int votesA;
  final int votesB;
  final List<String> voters;
  final String status; // 'aktiv' ose 'mbyllur'
  final DateTime createdAt;

  const Poll({
    required this.id,
    required this.userId,
    required this.author,
    required this.question,
    required this.optionA,
    required this.optionB,
    required this.votesA,
    required this.votesB,
    required this.voters,
    required this.status,
    required this.createdAt,
  });

  factory Poll.fromJson(Map<String, dynamic> json) {
    List<String> parsedVoters = [];
    if (json['voters'] is List) {
      parsedVoters = (json['voters'] as List).map((v) => v.toString()).toList();
    }
    return Poll(
      id: json['id'],
      userId: json['user_id'],
      author: json['author'] ?? 'Anonim',
      question: json['question'],
      optionA: json['option_a'],
      optionB: json['option_b'],
      votesA: (json['votes_a'] ?? 0) as int,
      votesB: (json['votes_b'] ?? 0) as int,
      voters: parsedVoters,
      status: json['status'] ?? 'aktiv',
      createdAt: DateTime.parse(json['created_at']),
    );
  }

  bool get isMine => userId == currentSession?.userId;
  bool get isActive => status == 'aktiv';
  bool get hasVoted => currentSession != null && voters.contains(currentSession!.userId);
  int get totalVotes => votesA + votesB;

  double get percentA => totalVotes == 0 ? 0.0 : (votesA / totalVotes);
  double get percentB => totalVotes == 0 ? 0.0 : (votesB / totalVotes);
}

// ======================= OPERACIONET REST ME SUPABASE (K4, K10, K11, K12) =======================

// K4 – Leximi nga databaza me filtër (all, aktiv, mbyllur, mine)
Future<List<Poll>> fetchPolls({String filter = 'all'}) async {
  var url = '$pollsUrl?select=*&order=created_at.desc&limit=100';
  if (filter == 'aktiv' || filter == 'mbyllur') {
    url = '$url&status=eq.$filter';
  } else if (filter == 'mine' && currentSession != null) {
    url = '$url&user_id=eq.${currentSession!.userId}';
  }

  final response = await http.get(Uri.parse(url), headers: authHeaders());
  if (response.statusCode != 200) {
    throw Exception('Gabim gjatë leximit (${response.statusCode}): ${response.body}');
  }

  final List<dynamic> rows = jsonDecode(response.body);
  return rows.map((r) => Poll.fromJson(r)).toList();
}

// K10 – Shtimi i një votimi të ri (POST)
Future<void> addPoll(String question, String optionA, String optionB) async {
  final response = await http.post(
    Uri.parse(pollsUrl),
    headers: authHeaders(),
    body: jsonEncode({
      'question': question,
      'option_a': optionA,
      'option_b': optionB,
      'author': currentSession?.email ?? 'Anonim',
      'votes_a': 0,
      'votes_b': 0,
      'voters': [],
      'status': 'aktiv',
    }),
  );

  if (response.statusCode != 201) {
    throw Exception('Nuk u krijua votimi (${response.statusCode}): ${response.body}');
  }
}

// K11 – Hedhja e votës (PATCH: shton votën dhe regjistron votuesin)
Future<void> castVote(Poll poll, String chosenOption) async {
  final userId = currentSession!.userId;
  if (poll.voters.contains(userId)) {
    throw Exception('Ju tashmë keni votuar në këtë sondazh!');
  }
  if (!poll.isActive) {
    throw Exception('Ky votim është mbyllur tashmë.');
  }

  final updatedVoters = List<String>.from(poll.voters)..add(userId);
  final newVotesA = chosenOption == 'a' ? poll.votesA + 1 : poll.votesA;
  final newVotesB = chosenOption == 'b' ? poll.votesB + 1 : poll.votesB;

  final response = await http.patch(
    Uri.parse('$pollsUrl?id=eq.${poll.id}'),
    headers: authHeaders(),
    body: jsonEncode({
      'votes_a': newVotesA,
      'votes_b': newVotesB,
      'voters': updatedVoters,
    }),
  );

  if (response.statusCode != 204) {
    throw Exception('Dështoi votimi (${response.statusCode}): ${response.body}');
  }
}

// K11 – Mbyllja e votimit (vetëm pronari, sipas RLS)
Future<void> closePoll(Poll poll) async {
  final response = await http.patch(
    Uri.parse('$pollsUrl?id=eq.${poll.id}'),
    headers: authHeaders(),
    body: jsonEncode({'status': 'mbyllur'}),
  );

  if (response.statusCode != 204) {
    throw Exception('Nuk u mbyll sondazhi (${response.statusCode}): ${response.body}');
  }
}

// K12 – Fshirja e votimit (vetëm pronari, sipas RLS)
Future<void> deletePoll(int id) async {
  final response = await http.delete(
    Uri.parse('$pollsUrl?id=eq.$id'),
    headers: authHeaders(),
  );

  if (response.statusCode != 204) {
    throw Exception('Nuk u fshi (${response.statusCode}): ${response.body}');
  }
}

String formatTime(DateTime t) {
  final l = t.toLocal();
  final d = l.day.toString().padLeft(2, '0');
  final m = l.month.toString().padLeft(2, '0');
  final h = l.hour.toString().padLeft(2, '0');
  final min = l.minute.toString().padLeft(2, '0');
  return '$d.$m $h:$min';
}

// ======================= STRUKTURA E APP-IT (K15, K16) =======================
class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _isDark = false;

  void _onLogin(Session session) {
    setState(() {
      currentSession = session;
    });
  }

  Future<void> _logout() async {
    await signOut();
    setState(() {
      currentSession = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Votim Live',
      debugShowCheckedModeBanner: false,
      // K15 – Tema moderne Material 3 dhe Dark Mode
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.light,
        ),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      themeMode: _isDark ? ThemeMode.dark : ThemeMode.light,
      // K7 – Porta e hyrjes: LoginPage ose HomeShell
      home: currentSession == null
          ? LoginPage(onLogin: _onLogin)
          : HomeShell(
              isDark: _isDark,
              onThemeChanged: (val) => setState(() => _isDark = val),
              onLogout: _logout,
            ),
    );
  }
}

// ======================= FAQJA E HYRJES / REGJISTRIMIT (K7) =======================
class LoginPage extends StatefulWidget {
  final ValueChanged<Session> onLogin;
  const LoginPage({super.key, required this.onLogin});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit(bool isRegister) async {
    final email = _emailController.text.trim();
    final password = _passwordController.text;

    if (!email.contains('@') || password.length < 6) {
      setState(() {
        _error = 'Shkruani një email të vlefshëm dhe fjalëkalim me së paku 6 karaktere.';
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final session = isRegister
          ? await signUp(email, password)
          : await signIn(email, password);
      widget.onLogin(session);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Votim Live'),
        centerTitle: true,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.how_to_vote, size: 76, color: colorScheme.primary),
              const SizedBox(height: 12),
              Text(
                'Platforma e Votimit Live',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              const Text('Krijoni sondazhe dhe votoni në kohë reale'),
              const SizedBox(height: 24),
              TextField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  prefixIcon: Icon(Icons.email_outlined),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Fjalëkalimi',
                  prefixIcon: Icon(Icons.lock_outline),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 14),
              if (_error != null)
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: colorScheme.errorContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _error!,
                    style: TextStyle(color: colorScheme.onErrorContainer),
                    textAlign: TextAlign.center,
                  ),
                ),
              const SizedBox(height: 16),
              if (_loading)
                const CircularProgressIndicator()
              else ...[
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: FilledButton(
                    onPressed: () => _submit(false),
                    child: const Text('Kyçu', style: TextStyle(fontSize: 16)),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: OutlinedButton(
                    onPressed: () => _submit(true),
                    child: const Text('Regjistrohu', style: TextStyle(fontSize: 16)),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// ======================= NAVIGIMI ME NAVIGATIONBAR (K16) =======================
class HomeShell extends StatefulWidget {
  final bool isDark;
  final ValueChanged<bool> onThemeChanged;
  final VoidCallback onLogout;

  const HomeShell({
    super.key,
    required this.isDark,
    required this.onThemeChanged,
    required this.onLogout,
  });

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final List<String> _titles = const ['Të gjitha Votimet', 'Votimet e Mia', 'Profili'];

  @override
  Widget build(BuildContext context) {
    final pages = [
      const PollsPage(key: ValueKey('all_polls'), onlyMine: false),
      const PollsPage(key: ValueKey('my_polls'), onlyMine: true),
      ProfilePage(
        isDark: widget.isDark,
        onThemeChanged: widget.onThemeChanged,
        onLogout: widget.onLogout,
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_index]),
        elevation: 1,
      ),
      body: pages[_index],
      // K16 – NavigationBar moderne me 3 destinacione
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.how_to_vote_outlined),
            selectedIcon: Icon(Icons.how_to_vote),
            label: 'Votimet',
          ),
          NavigationDestination(
            icon: Icon(Icons.ballot_outlined),
            selectedIcon: Icon(Icons.ballot),
            label: 'Të miat',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Profili',
          ),
        ],
      ),
    );
  }
}

// ======================= LISTA DHE EKRANI LIVE I VOTIMEVE (K5, K6, K8, K9, K13, K14) =======================
class PollsPage extends StatefulWidget {
  final bool onlyMine;
  const PollsPage({super.key, required this.onlyMine});

  @override
  State<PollsPage> createState() => _PollsPageState();
}

class _PollsPageState extends State<PollsPage> {
  final _controller = StreamController<List<Poll>>(); // K13
  Timer? _timer; // K13: Përditësim periodik çdo 5 sekonda
  String _filter = 'all'; // K14: Filtrat me ChoiceChip

  final _questionController = TextEditingController();
  final _optionAController = TextEditingController();
  final _optionBController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
    // K13 – Përditësimi live në prapaskenë çdo 5s
    _timer = Timer.periodic(const Duration(seconds: 5), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.close();
    _questionController.dispose();
    _optionAController.dispose();
    _optionBController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final polls = await fetchPolls(filter: widget.onlyMine ? 'mine' : _filter);
      if (!_controller.isClosed) _controller.add(polls);
    } catch (e) {
      if (!_controller.isClosed) _controller.addError(e);
    }
  }

  // K18 – Feedback vizual me SnackBar
  void _showMessage(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  // K9 & K10 – Dialog me formë dhe validim për krijimin e një votimi
  void _showAddDialog() {
    _questionController.clear();
    _optionAController.clear();
    _optionBController.clear();

    showDialog(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        title: const Text('Krijo Votim të Ri'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _questionController,
                decoration: const InputDecoration(
                  labelText: 'Pyetja e sondazhit',
                  hintText: 'p.sh. Cila gjuhë ju pëlqen më shumë?',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _optionAController,
                decoration: const InputDecoration(
                  labelText: 'Opsioni A',
                  hintText: 'p.sh. Flutter / Dart',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _optionBController,
                decoration: const InputDecoration(
                  labelText: 'Opsioni B',
                  hintText: 'p.sh. Python',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogCtx),
            child: const Text('Anulo'),
          ),
          FilledButton(
            onPressed: () async {
              final q = _questionController.text.trim();
              final optA = _optionAController.text.trim();
              final optB = _optionBController.text.trim();

              // K10 – Validimi i formës
              if (q.length < 3 || optA.isEmpty || optB.isEmpty) {
                _showMessage('Plotësoni pyetjen (3+ shkronja) dhe të dy opsionet.');
                return;
              }

              Navigator.pop(dialogCtx);
              try {
                await addPoll(q, optA, optB);
                await _load();
                _showMessage('U publikua votimi: $q 🎉');
              } catch (e) {
                _showMessage('Gabim gjatë krijimit: $e');
              }
            },
            child: const Text('Krijo'),
          ),
        ],
      ),
    );
  }

  // K12 – Fshirja e votimit vetëm nga krijuesi (pronari)
  void _confirmDelete(Poll poll) {
    if (!poll.isMine) {
      _showMessage('Mund të fshini vetëm votimet tuaja!');
      return;
    }

    showDialog(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        title: const Text('Fshi votimin?'),
        content: Text('A jeni të sigurt që dëshironi të fshini:\n"${poll.question}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogCtx),
            child: const Text('Anulo'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
            ),
            onPressed: () async {
              Navigator.pop(dialogCtx);
              try {
                await deletePoll(poll.id);
                await _load();
                _showMessage('Votimi u fshi me sukses.');
              } catch (e) {
                _showMessage('Nuk u fshi: $e');
              }
            },
            child: const Text('Fshi'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: Column(
        children: [
          // K14 – Filtrat me ChoiceChip për listën e përgjithshme
          if (!widget.onlyMine)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  for (final f in const [
                    ['all', 'Të gjitha'],
                    ['aktiv', 'Aktive'],
                    ['mbyllur', 'Të mbyllura'],
                  ]) ...[
                    ChoiceChip(
                      label: Text(f[1]),
                      selected: _filter == f[0],
                      onSelected: (_) {
                        setState(() => _filter = f[0]);
                        _load();
                      },
                    ),
                    const SizedBox(width: 8),
                  ],
                ],
              ),
            ),
          Expanded(
            // K6 – Katër gjendjet e StreamBuilder: error, waiting, empty, data
            child: StreamBuilder<List<Poll>>(
              stream: _controller.stream,
              builder: (context, snapshot) {
                // Gjendja 1: Error
                if (snapshot.hasError) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.cloud_off, size: 54, color: Colors.grey),
                          const SizedBox(height: 12),
                          const Text(
                            'Nuk u lidh me databazën.',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 12),
                          FilledButton.icon(
                            onPressed: _load,
                            icon: const Icon(Icons.refresh),
                            label: const Text('Provo përsëri'),
                          ),
                        ],
                      ),
                    ),
                  );
                }

                // Gjendja 2: Waiting
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final polls = snapshot.data!;

                // Gjendja 3: Empty
                if (polls.isEmpty) {
                  return Center(
                    child: Text(
                      widget.onlyMine
                          ? 'Nuk keni krijuar asnjë sondazh ende.'
                          : 'Asnjë votim i gjetur në këtë filtër.',
                      style: const TextStyle(fontSize: 15, color: Colors.grey),
                    ),
                  );
                }

                // Gjendja 4: Data (K5 – ListView.builder)
                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  itemCount: polls.length,
                  itemBuilder: (context, index) {
                    final poll = polls[index];
                    final isClosed = !poll.isActive;

                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 6),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: isClosed
                              ? Colors.grey.shade400
                              : theme.colorScheme.primaryContainer,
                          child: Icon(
                            isClosed ? Icons.lock : Icons.poll,
                            color: isClosed
                                ? Colors.white
                                : theme.colorScheme.onPrimaryContainer,
                          ),
                        ),
                        title: Text(
                          poll.question,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 4),
                            Text('Nga: ${poll.author} • ${formatTime(poll.createdAt)}'),
                            const SizedBox(height: 4),
                            Text(
                              'Gjithsej vota: ${poll.totalVotes}' +
                                  (poll.hasVoted ? ' • ✅ Keni votuar' : ''),
                              style: TextStyle(
                                fontSize: 12,
                                color: poll.hasVoted ? Colors.green : null,
                                fontWeight: poll.hasVoted ? FontWeight.bold : FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                        trailing: Chip(
                          label: Text(
                            poll.isActive ? 'Aktiv' : 'Mbyllur',
                            style: TextStyle(
                              fontSize: 11,
                              color: poll.isActive ? Colors.green.shade800 : Colors.grey.shade800,
                            ),
                          ),
                          backgroundColor: poll.isActive
                              ? Colors.green.shade100
                              : Colors.grey.shade200,
                          padding: EdgeInsets.zero,
                        ),
                        // K8 – Kalimi në faqen e detajeve dhe votimit
                        onTap: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => PollDetailPage(poll: poll),
                            ),
                          );
                          _load();
                        },
                        // K12 – Mbajtja shtypur për fshirje (vetëm pronari)
                        onLongPress: () => _confirmDelete(poll),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddDialog,
        icon: const Icon(Icons.add),
        label: const Text('Krijo Votim'),
      ),
    );
  }
}

// ======================= FAQJA E DETAJEVE DHE VOTIMIT LIVE (K8, K11) =======================
class PollDetailPage extends StatefulWidget {
  final Poll poll;
  const PollDetailPage({super.key, required this.poll});

  @override
  State<PollDetailPage> createState() => _PollDetailPageState();
}

class _PollDetailPageState extends State<PollDetailPage> {
  late Poll _currentPoll;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _currentPoll = widget.poll;
  }

  Future<void> _handleVote(String option) async {
    setState(() => _loading = true);
    try {
      await castVote(_currentPoll, option);
      // Rifreskojmë të dhënat pas votës
      final updatedList = await fetchPolls();
      final fresh = updatedList.firstWhere((p) => p.id == _currentPoll.id, orElse: () => _currentPoll);
      setState(() {
        _currentPoll = fresh;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Vota juaj u regjistrua me sukses! 🎉')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gabim: $e')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _handleClosePoll() async {
    setState(() => _loading = true);
    try {
      await closePoll(_currentPoll);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Votimi u mbyll me sukses.')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gabim: $e')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final hasVoted = _currentPoll.hasVoted;
    final isActive = _currentPoll.isActive;

    final pctA = (_currentPoll.percentA * 100).toStringAsFixed(1);
    final pctB = (_currentPoll.percentB * 100).toStringAsFixed(1);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detajet e Votimit'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Titulli i pyetjes
            Text(
              _currentPoll.question,
              style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Icon(Icons.person_pin, size: 16, color: theme.colorScheme.secondary),
                const SizedBox(width: 4),
                Text('Krijuar nga: ${_currentPoll.author}', style: const TextStyle(fontSize: 13)),
              ],
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.access_time, size: 16, color: theme.colorScheme.secondary),
                const SizedBox(width: 4),
                Text('Data: ${formatTime(_currentPoll.createdAt)}', style: const TextStyle(fontSize: 13)),
              ],
            ),
            const SizedBox(height: 8),
            Chip(
              avatar: Icon(isActive ? Icons.check_circle : Icons.lock, size: 16),
              label: Text(isActive ? 'Votimi është Aktiv' : 'Votimi është Mbyllur'),
              backgroundColor: isActive ? Colors.green.shade50 : Colors.grey.shade200,
            ),
            const Divider(height: 32),

            // Shiritat Live të Rezultateve
            Text(
              'Rezultatet Live (${_currentPoll.totalVotes} vota gjithsej):',
              style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 16),

            // Kartela Opsioni A
            Card(
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            _currentPoll.optionA,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Text('$pctA% (${_currentPoll.votesA} vota)'),
                      ],
                    ),
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                        value: _currentPoll.percentA,
                        minHeight: 12,
                        backgroundColor: Colors.grey.shade300,
                        valueColor: AlwaysStoppedAnimation<Color>(theme.colorScheme.primary),
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (isActive && !hasVoted)
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: _loading ? null : () => _handleVote('a'),
                          icon: const Icon(Icons.touch_app),
                          label: Text('Voto për "${_currentPoll.optionA}"'),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),

            // Kartela Opsioni B
            Card(
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            _currentPoll.optionB,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Text('$pctB% (${_currentPoll.votesB} vota)'),
                      ],
                    ),
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                        value: _currentPoll.percentB,
                        minHeight: 12,
                        backgroundColor: Colors.grey.shade300,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.teal),
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (isActive && !hasVoted)
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: _loading ? null : () => _handleVote('b'),
                          icon: const Icon(Icons.touch_app),
                          label: Text('Voto për "${_currentPoll.optionB}"'),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            if (hasVoted)
              const Center(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.verified, color: Colors.green),
                      SizedBox(width: 8),
                      Text('Ju e keni regjistruar votën tuaj.', style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),

            // K11 – Butoni i pronarit për mbylljen e sondazhit
            if (_currentPoll.isMine && isActive) ...[
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                  ),
                  onPressed: _loading ? null : _handleClosePoll,
                  icon: const Icon(Icons.lock_clock),
                  label: const Text('Mbyll Votimin (Pronari)'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ======================= FAQJA E PROFILIT DHE TEMA (K15, K17) =======================
class ProfilePage extends StatelessWidget {
  final bool isDark;
  final ValueChanged<bool> onThemeChanged;
  final VoidCallback onLogout;

  const ProfilePage({
    super.key,
    required this.isDark,
    required this.onThemeChanged,
    required this.onLogout,
  });

  @override
  Widget build(BuildContext context) {
    final email = currentSession?.email ?? 'pa-email';
    final initial = email.isNotEmpty ? email[0].toUpperCase() : '?';

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SizedBox(height: 10),
        Center(
          child: CircleAvatar(
            radius: 46,
            backgroundColor: Theme.of(context).colorScheme.primaryContainer,
            child: Text(
              initial,
              style: TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onPrimaryContainer,
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Center(
          child: Text(
            email,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
        ),
        const SizedBox(height: 24),
        Card(
          child: Column(
            children: [
              SwitchListTile(
                title: const Text('Dark Mode (Tema e Errët)'),
                secondary: const Icon(Icons.dark_mode_outlined),
                value: isDark,
                onChanged: onThemeChanged,
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.red),
                title: const Text('Dil (Sign Out)', style: TextStyle(color: Colors.red)),
                onTap: onLogout,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
